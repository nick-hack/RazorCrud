﻿using CrudRazorpage.Models;
using Microsoft.EntityFrameworkCore;

namespace CrudRazorpage.DAL
{
    public class AppDbContaxt : DbContext
    {
        public AppDbContaxt(DbContextOptions options) : base(options)
        {
        }

        public virtual DbSet<Employee> Employees { get; set; }

    }
}
