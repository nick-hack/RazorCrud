
Mvc Application Employees (Create, Read,Update,Delete).
I'll Use in the project Swagger. 


Setup
 -- ASP.NET Web Application MVC (Razor)
-- First :- Add-Migration
--Second :- Update-Database


then run the project